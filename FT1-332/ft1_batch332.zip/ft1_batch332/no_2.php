<?php
/*
Sebuah perusahaan platform jejaring sosial memilki ketentuan format username yang digunakan untuk login oleh para pengguna. Butlah validasi untuk memastikan apakah username tersebut sudah valid atau belum.

Input: string username
Output: valid / invalid
Constraints:
- terdiri dari 5 hingga 10 karakter
- karakter yang diboleh digunakan hanya alfanumerik dan garis bawah (_)
- username wajib mengandung garis bawah (_)

Example 1:
username = abc
output: invalid

Example 2:
username = abc_123
output: valid

Example 3:
username = A1B2C3__
output: valid

Example 4:
username = A1B2C3__abc
output: invalid

Notes:
Karakter alfanumerik yaitu karakter yang terdiri dari karakter huruf kecil [a-z], karakter huruf besar [A-Z], dan angka [0-9]
*/

function validateUserName($username)
{
    // Memeriksa panjang username
    if (strlen($username) < 5 || strlen($username) > 10) {
        return "invalid";
    }

    // Memeriksa karakter yang digunakan
    if (!ctype_alnum($username) && strpos($username, '_') === false) {
        return "invalid";
    }

    // Memeriksa apakah username mengandung garis bawah
    if (strpos($username, '_') === false) {
        return "invalid";
    }

    return "valid";
}

// Melakukan input
$username = readline("Masukkan username: ");

// Melakukan validasi
$validationResult = validateUserName($username);

// Menampilkan hasil validasi
echo "Hasil validasi: " . $validationResult . "\n";
