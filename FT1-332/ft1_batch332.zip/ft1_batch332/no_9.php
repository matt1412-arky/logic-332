<?php
/*
Anda memiliki daftar string, tugas Anda adalah mengelompokkan tiap kata sesuai dengan masing-masing 
panjang karakter.

Constraints:
- Panjang daftar kata: 1 <= words <= 50
- Panjang tiap kata: 1 <= words[i] <= 7

Input: words(a list of strings)

Example:
words: saya mau memakan tahu dan minum teh

Output:
mau, dan, teh
saya, tahu
minum
memakan
*/
function groupAnagrams($words)
{
    $result = [];

    foreach ($words as $word) {
        $sortedWord = str_split($word);
        sort($sortedWord);
        $sortedWord = implode('', $sortedWord);

        if (isset($result[$sortedWord])) {
            $result[$sortedWord][] = $word;
        } else {
            $result[$sortedWord] = [$word];
        }
    }

    return array_values($result);
}

function sortWordsByLength($a, $b)
{
    return strlen($a) - strlen($b);
}

$input = readline("Masukkan kata-kata: ");
$words = explode(' ', $input);
usort($words, 'sortWordsByLength');
print_r(groupAnagrams($words));
