<?php
/*
Buatlah format penjumlahan seperti contoh di bawah ini,

Input: n (deret angka)
Output: penjumlahan seperti contoh
Constraint: angka bisa berupa bilangan bulat positif, bilangan bulat negatif, ataupun desimal

Example 1:
n = 4    1    3
output:
4
4 + 1 = 5
4 + 1 + 3 = 8

Example 2:
n = 2    2    3    0    8
output:
2
2 + 2 = 4
2 + 2 + 3 = 7
2 + 2 + 3 + 0 = 7
2 + 2 + 3 + 0 + 8 = 15
*/

function sum_numbers($n)
{
    $numbers = array();
    for ($i = 0; $i < $n; $i++) {
        $numbers[] = readline("Masukkan angka ke-" . ($i + 1) . ": ");
    }
    $result = 0;
    foreach ($numbers as $num) {
        $result += $num;
        echo $result . " ";
    }
}

$n = readline("Masukkan jumlah angka: ");
sum_numbers($n);
