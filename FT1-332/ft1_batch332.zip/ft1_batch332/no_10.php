<?php
/*
Ada berapa banyak huruf konsonan yang pada sebuah kalimat yang setelahnya merupakan huruf vokal!

Input: string kalimat
Output: banyaknya group konsonal-vokal

Example 1:
string s = Apa kabar kalian semua ?
output = 7
*/
