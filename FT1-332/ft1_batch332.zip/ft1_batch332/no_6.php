<?php
/*
------------------
|   3   |   5   |   3   |
 ------------------
|   5   |   8   |   5   |
 ------------------
|   3   |   5   |   3   |
 ------------------
Terdapat 9 kotak dengan bobot sesuai dengan angka yang tertera pada masing-masing kotak tersebut, 
kita akan bermain dengan 2 player(A & B) untuk menentukan siapa yang akan mendapatkan total angka 
terbanyak dalam 3x putaran permainan. Pengguna harus memilih player mana yang akan menang dalam 
3 putaran tersebut. Cara bermainnya yaitu dengan mengacak angka dari 1-9.

Input: pilihan player
Output: player yang menang dan kalah
Urutan angka kotak:
1    2    3
4    5    6
7    8    9

Example:
player pilihan: A
output:
Round 1 => A = 3, B = 5
Nilai A = 3, B = 8

Round 2 => A = 1, B = 9
Nilai A = 6, B = 11

Round 3 => A = 4, B = 4
Nilai A = 11, B = 16

Anda kalah, B menang
*/

// Fungsi untuk mengacak angka
function acak_angka()
{
    $angka = [1, 2, 3, 4, 5, 6, 7, 8, 9];
    shuffle($angka);
    return $angka;
}

// Fungsi utama
function main()
{
    // Memilih player yang akan menang
    $player_menang = readline("Player pilihan: ");

    // Mengacak angka
    $angka = acak_angka();

    // Menentukan total angka awal
    $total_awal = 0;

    // Melakukan permainan untuk 3 kali
    for ($i = 0; $i < 3; $i++) {
        // Menampilkan pesan round
        echo "Round " . ($i + 1) . " => " . $player_menang . " = " . $angka[$i] . ", B= " . $angka[$i + 1] . "\n";

        // Menambahkan angka ke total
        if ($player_menang == "A") {
            $total_awal += $angka[$i];
        } else {
            $total_awal -= $angka[$i];
        }

        // Menampilkan nilai total
        echo "Nilai A = " . $total_awal . ", B = " . ($total_awal) . "\n";
    }

    // Menentukan player yang menang
    if ($total_awal > 0) {
        echo "Selamat! Anda menang\n";
    } else {
        if ($player_menang == "B") {
            echo "Anda kalah, A menang\n";
        } else {
            echo "Anda kalah, B menang\n";
        }
    }
}

// Menjalankan fungsi utama
main();
