<?php
/*
Buatlah program untuk membersihkan data sampah pada input yang dimasukkan!

Input: string kata atau kalimat
Output: string yang sudah di cleansing
Constraints:
- karakter dan kata yang termasuk sampah(perlu di cleansing): koma(,), kutip satu('), kutip dua("), anotasi(@), kata yang sama, garis miring(/), dan(&)
- tiap suku kata hanya dipisah dengan 1 spasi

Example 1:
string: He is a very very good boy, isn't he?
output: He is a very good boy isnt he?

Example 2:
string: public static void main(String[] args) {
output: public static void main(String[] args) {
*/

function clean_garbage($input_string)
{
    // Menghapus koma
    $input_string = str_replace(',', '', $input_string);

    // Menghapus kutip satu
    $input_string = str_replace("'", '', $input_string);

    // Menghapus kutip dua
    $input_string = str_replace('"', '', $input_string);

    // Menghapus anotasi
    $input_string = str_replace('@', '', $input_string);

    // Menghapus kata yang sama
    $words = explode(' ', $input_string);
    $unique_words = array_unique($words);
    $input_string = implode(' ', $unique_words);

    // Menghapus garis miring
    $input_string = str_replace('/', '', $input_string);

    // Menghapus tanda dan(&)
    $input_string = str_replace('&', '', $input_string);

    // Menghapus spasi duplikat
    $input_string = str_replace('  ', ' ', $input_string);

    return trim($input_string);
}

// Implementasi
$input_string = readline("Masukkan kata/kalimat: ");
$output_string = clean_garbage($input_string);
echo $output_string;
