<?php
/*
Sebuah negara dengan total penduduk n akan melakukan pemilihan calon anggota legislatif. 
Sistem pemilu di negara tersebut menetapkan jumlah calon anggota legislatif sebanyak m. 
Tampilkan perolehan suara dari masing-masing calon anggota legislatif!

Input: n, m
Output: perolehan suara
Constraints:
- diurutkan berdasarkan suara terbanyak
- total suara dari seluruh calon anggota legislatif tidak boleh > dari n (total penduduk)
- gunakan fungsi random sebanyak n untuk mendapatkan suara masing-masing calon
- persentase sampai 2 digit dibelakang koma

Example 1:
n = 1000
m = 3
output:
Calon no. urut 1: 420 suara (42,00 %)
Calon no. urut 2: 122 suara (12,20 %)
Calon no. urut 3: 80 suara (8,00 %)
Golput: 378 (37,80 %)
*/

function hitung_golput($n, $m)
{
    // Membuat array kosong untuk menyimpan suara dari setiap calon
    $suara = array_fill(0, $m, 0);

    // Menggunakan fungsi rand untuk mendapatkan suara dari setiap calon
    for ($i = 0; $i < $n; $i++) {
        $calon = rand(0, $m - 1);
        if ($calon < $m) {
            $suara[$calon] += 1;
        }
    }

    rsort($suara);

    // Menghitung total suara
    $total_suara = array_sum($suara);

    // Menghitung persentase dari setiap calon
    $persentase = array_map(function ($s) use ($total_suara) {
        return $s / $total_suara * 100;
    }, $suara);

    // Menampilkan hasil perolehan suara dari setiap calon
    for ($i = 0; $i < $m; $i++) {
        echo "Calon no. urut " . ($i + 1) . ": " . $suara[$i] . " suara (" . number_format($persentase[$i], 2) . "%)\n";
    }

    // Menampilkan golput
    $golput = $total_suara - array_sum($suara);
    echo "Golput: " . $golput . " (" . number_format($golput / $total_suara * 100, 2) . "%)";
}

// Contoh penggunaan
$n = readline("Masukkan jumlah penduduk: ");
$m = readline("Masukkan jumlah kandidat: ");
hitung_golput($n, $m);
