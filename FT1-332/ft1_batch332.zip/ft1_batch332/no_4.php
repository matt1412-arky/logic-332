<?php
/*
Sebuah buku terdiri dari n halaman, terdapat masing-masing 1 lembar cover pada bagian depan dan 
belakang buku. Tiap halaman ganjil, selalu ada pada bagian kanan buku. Tentukan pada lembar ke berapa 
halaman x pada buku tersebut.

Input: n, x
Output: lember ke-

Example 1:
n = 10
x = 5
output: lembar ke-3

Example 2:
n = 15
x = 9
output: lembar ke-5
*/

$n = readline("Masukkan jumlah halaman: ");
$x = readline("Masukkan halaman yang ingin dicari: ");

if ($x % 2 == 0) {
    $lembar = round($x / 2);
} else {
    $lembar = round($x / 2);
}

echo "Lembar ke- " . $lembar;
