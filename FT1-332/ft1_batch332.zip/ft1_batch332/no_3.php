<?php
/*
Kalian diberikan input string berupa kata atau kalimat dan input n yang merupakan panjang penggalan kata. 
Tugas kalian untuk memenggal kata atau kalimat yang diinput seperti contoh di bawah.

Input:
- string kata atau kalimat
- n (panjang penggalan kata)
Output: kumpulan penggalan kata dalam bentuk array
Constraints:
- terdiri dari huruf abjad [a-z, A-Z]
- memenggal kata dari depan dan belakang
- diurutkan secara ascending

Example 1:
string: Hallo, apa kabar kalian?
n: 4
output: ["akab", "arka", "Hall", "kaba", "lian", "loap", "oapa", "rkal"]

Example 2:
string: Makan malam?
n: 2
output: ["al", "al", "am", "am", "ka", "ka", "Ma", "Ma", "nm", "nm"]
*/

function penggalan_kata()
{
    $string = readline("Masukkan string: ");
    $n = readline("Masukkan panjang penggalan: ");

    $penggalan = [];
    $words = preg_split('/\s+/', $string);
    $words = str_replace(" ", "", $words);
    $words = str_replace(",", "", $words);
    $words = str_replace("?", "", $words);
    // sort($words);
    // print_r($words);
    foreach ($words as $word) {
        $wordLength = strlen($word);
        for ($i = 0; $i <= $wordLength - $n; $i++) {
            $penggalan[] = substr($word, $i, $n);
            sort($penggalan);
        }
    }
    return $penggalan;
}

$result = penggalan_kata();
print_r($result);
