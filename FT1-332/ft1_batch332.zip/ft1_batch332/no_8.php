<?php
/*
Soal ini terdiri dari pola deret angka 3x3 yang nantinya akan diolah menggunakan operasi aritmatika 
dasar yang ditentukan melalui input

Input:
- 3 deret angka(dinamis sesuai input)
- pola (terdiri dari pola x, +, atau -)
- action (tediri dari operasi aritmatika tambah / kurang / kali)
Output: hasil dari operasi aritmatika
Constraints:
- hanya berupa bilangan bulat positif dan atau bilangan bulat negatif (include angka 0)

Example 1:
0    1    2
3    4    5
6    7    8
pola: x
action: +
penjelasan: (0 + 4 + 8) + (2 + 4 + 6) = 24

output: 24

Example 2:
0    1    2
3    4    5
6    7    8
pola: -
action: x
penjelasan: 3 x 4 x 5 = 60

output: 60
*/

// Mengambil deret angka dari pengguna
$deret = [];
while (true) {
    $input = readline("Masukkan angka (atau tekan Enter untuk selesai): ");
    if ($input == "") {
        break;
    }
    $deret[] = $input;
}

// Mengambil pola dari pengguna
$pola = readline("Masukkan pola (x, +, atau -): ");

// Mengambil aksi dari pengguna
$aksi = readline("Masukkan aksi (+, -, atau *): ");

// Melakukan operasi aritmatika sesuai dengan pola dan aksi yang diinputkan
$hasil = 0;
for ($i = 0; $i < count($deret); $i += 3) {
    $angka1 = $deret[$i];
    $angka2 = $deret[$i + 1];
    $angka3 = $deret[$i + 2];

    print_r($angka1);
    print_r($angka2);
    print_r($angka3);

    if ($aksi == "*") {
        $hasil += $angka1 * $angka2 * $angka3;
    } elseif ($aksi == "+") {
        $hasil += $angka1 + $angka2 + $angka3;
    } elseif ($aksi == "-") {
        $hasil += $angka1 - $angka2 - $angka3;
    }
}

// Menampilkan hasil
echo "Hasil: " . $hasil;
